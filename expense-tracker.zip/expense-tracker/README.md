# Personal Expense Tracker (CLI)

A command-line application for tracking income and expenses, setting monthly category
budgets, and viewing spending reports. Built with Python and SQLite, using only the
standard library.

## Overview
Users register an account, log transactions, set budgets per category and month, and get
alerts when spending approaches or exceeds a budget. Reports show a monthly summary,
category-wise breakdown and a multi-month trend using text bar charts. All data is stored
locally in a SQLite file.

## Features
- Register / login with salted PBKDF2-SHA256 password hashing
- Add, view, edit, delete transactions (income or expense)
- Search by category, type, date range, amount range, and keyword
- Monthly budgets with WARNING (>= 80%) and EXCEEDED alerts
- Monthly summary, category breakdown, trend chart (text based)
- Export all transactions to CSV
- Input validation, error handling and file logging (`logs/app.log`)
- Unit tests (22 tests)

## Technologies Used
- Python 3.8 or newer (standard library only)
- SQLite (via `sqlite3`)
- `unittest` for testing, `logging` for logs, `argparse` for the entry point

## Project Structure
```
├── main.py               # entry point
├── statement.md          # problem statement
├── requirements.txt
├── src/
│   ├── auth.py           # register / login, password hashing
│   ├── budget.py         # budgets and alerts
│   ├── cli.py            # interactive menus
│   ├── database.py       # schema and connection
│   ├── demo.py           # non-interactive demo
│   ├── logger.py         # logging setup
│   ├── models.py         # data classes
│   ├── reports.py        # summaries, trend, CSV export
│   ├── transactions.py   # CRUD and search
│   └── validators.py     # input validation
├── tests/                # unit tests
└── docs/                 # diagrams and project report
```

## Setup and Installation
1. Install Python 3.8+ and verify: `python --version` (use `python3` on Linux/macOS).
2. Clone the repository:
   ```
   git clone https://github.com/<your-username>/<repo-name>.git
   cd <repo-name>
   ```
3. (Optional) create a virtual environment:
   ```
   python -m venv .venv
   source .venv/bin/activate        # Windows: .venv\Scripts\activate
   ```
4. Install dependencies (none needed): `pip install -r requirements.txt`
5. No configuration is required. The database file `expenses.db` is created
   automatically in the current directory on first run.

## Running the Project
Interactive mode:
```
python main.py
```
Use a custom database file:
```
python main.py --db mydata.db
```
Quick demo (no prompts; creates user `demo` / password `demo1234`, seeds sample data,
and prints transactions, budget status and reports):
```
python main.py --demo
```

### Typical workflow
1. Choose **2. Register**, enter a username and password.
2. Choose **6. Set monthly budget** (e.g. Food, `2026-09`, `5000`).
3. Choose **1. Add transaction** and enter type, amount, category, date.
4. If the category budget is nearly used or exceeded, an alert is printed.
5. Use **8. Monthly report & trend** to see your summary and charts.

## Running the Tests
From the project root:
```
python -m unittest discover -s tests -t . -v
```
Expected result: `Ran 22 tests ... OK`.

## Error Handling and Logging
Invalid input (bad dates, negative amounts, unknown IDs, wrong password) shows a clear
message and never crashes the program. Events and errors are written to `logs/app.log`.

## Screenshots
Add screenshots of your own runs here (for example `docs/screenshots/demo.png`).

## Author
Your Name, Registration Number
