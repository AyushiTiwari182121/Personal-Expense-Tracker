# Problem Statement

## Problem
Many students and young professionals do not track where their money goes. Spreadsheets
are tedious to maintain, and most apps are heavy, require accounts on third-party
servers, or need a graphical interface. As a result people overspend without noticing
until the month is over.

## Proposed Solution
**Personal Expense Tracker** is a lightweight, offline command-line application that
lets a user record income and expenses, categorise them, set monthly budgets per
category, receive alerts when a budget is close to (or over) its limit, and view
reports of their spending habits.

## Scope
**In scope**
- Multi-user registration and login with securely hashed passwords
- Add, view, edit, delete and search income/expense transactions
- Category management (default categories plus user-defined ones)
- Monthly budgets with warning (>= 80%) and exceeded alerts
- Monthly summary, category breakdown, multi-month trend with text charts
- CSV export of transactions
- Local SQLite storage, logging, input validation, automated tests

**Out of scope**
- Graphical or web interface
- Bank/UPI integration or online sync
- Multi-currency conversion
- Password recovery by email

## Target Users
- College students managing a monthly allowance
- Early-career professionals who want a simple budgeting habit
- Anyone comfortable with a terminal who prefers private, offline data

## High-Level Features
1. User management (register / login / logout)
2. Transaction management (CRUD + filtered search)
3. Budgeting and analytics (budgets, alerts, reports, trend, CSV export)
