from src import auth, transactions as tx
from src.validators import ValidationError
from tests.base import DBTestCase


class TransactionTests(DBTestCase):
    def add(self, kind="expense", amount=100, cat="Food", date="2026-09-01", desc=""):
        return tx.add_transaction(self.conn, self.user.id, kind, amount, cat, date, desc)

    def test_add_and_get(self):
        t = self.add(amount=250.5, desc="lunch")
        self.assertEqual(tx.get_transaction(self.conn, self.user.id, t.id).amount, 250.5)

    def test_invalid_input_rejected(self):
        with self.assertRaises(ValidationError):
            self.add(amount=-1)
        with self.assertRaises(ValidationError):
            self.add(date="yesterday")

    def test_update(self):
        t = self.add()
        updated = tx.update_transaction(self.conn, self.user.id, t.id, amount="300", category="rent")
        self.assertEqual((updated.amount, updated.category), (300.0, "Rent"))

    def test_delete(self):
        t = self.add()
        tx.delete_transaction(self.conn, self.user.id, t.id)
        with self.assertRaises(ValidationError):
            tx.get_transaction(self.conn, self.user.id, t.id)

    def test_search_filters(self):
        self.add(amount=100, cat="Food", date="2026-09-01", desc="pizza")
        self.add(amount=900, cat="Rent", date="2026-09-02")
        self.add("income", 5000, "Salary", "2026-09-03")
        self.assertEqual(len(tx.search_transactions(self.conn, self.user.id, category="Food")), 1)
        self.assertEqual(len(tx.search_transactions(self.conn, self.user.id, tx_type="income")), 1)
        self.assertEqual(len(tx.search_transactions(self.conn, self.user.id, min_amount=500)), 2)
        self.assertEqual(len(tx.search_transactions(self.conn, self.user.id, keyword="pizza")), 1)
        self.assertEqual(len(tx.search_transactions(self.conn, self.user.id, date_from="2026-09-02")), 2)

    def test_users_cannot_touch_each_others_data(self):
        t = self.add()
        other = auth.register(self.conn, "other_user", "password1")
        with self.assertRaises(ValidationError):
            tx.delete_transaction(self.conn, other.id, t.id)
        self.assertEqual(tx.search_transactions(self.conn, other.id), [])
