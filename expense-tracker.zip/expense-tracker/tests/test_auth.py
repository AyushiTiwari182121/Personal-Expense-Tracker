from src import auth
from src.validators import ValidationError
from tests.base import DBTestCase


class AuthTests(DBTestCase):
    def test_login_success(self):
        user = auth.login(self.conn, "tester", "secret123")
        self.assertEqual(user.username, "tester")

    def test_wrong_password(self):
        with self.assertRaises(ValidationError):
            auth.login(self.conn, "tester", "wrong")

    def test_unknown_user(self):
        with self.assertRaises(ValidationError):
            auth.login(self.conn, "nobody", "secret123")

    def test_duplicate_username(self):
        with self.assertRaises(ValidationError):
            auth.register(self.conn, "tester", "another1")

    def test_password_not_stored_plain(self):
        row = self.conn.execute("SELECT password_hash FROM users").fetchone()
        self.assertNotIn("secret123", row["password_hash"])

    def test_same_password_different_salt(self):
        h1, _ = auth.hash_password("abc123")
        h2, _ = auth.hash_password("abc123")
        self.assertNotEqual(h1, h2)
