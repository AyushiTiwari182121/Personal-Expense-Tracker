import csv
import os
import tempfile

from src import budget, reports, transactions as tx
from tests.base import DBTestCase


class BudgetReportTests(DBTestCase):
    def add(self, kind, amount, cat, date):
        tx.add_transaction(self.conn, self.user.id, kind, amount, cat, date)

    def test_budget_status_and_states(self):
        budget.set_budget(self.conn, self.user.id, "Food", "2026-09", 1000)
        self.add("expense", 500, "Food", "2026-09-01")
        s = budget.budget_status(self.conn, self.user.id, "2026-09")[0]
        self.assertEqual((s.spent, s.remaining, s.state), (500.0, 500.0, "OK"))
        self.add("expense", 350, "Food", "2026-09-02")
        self.assertEqual(budget.budget_status(self.conn, self.user.id, "2026-09")[0].state, "WARNING")
        self.add("expense", 300, "Food", "2026-09-03")
        self.assertEqual(budget.budget_status(self.conn, self.user.id, "2026-09")[0].state, "EXCEEDED")

    def test_alert_message(self):
        budget.set_budget(self.conn, self.user.id, "Food", "2026-09", 100)
        self.add("expense", 150, "Food", "2026-09-01")
        self.assertIn("exceeded", budget.check_alert(self.conn, self.user.id, "Food", "2026-09-01"))
        self.assertIsNone(budget.check_alert(self.conn, self.user.id, "Rent", "2026-09-01"))

    def test_budget_update_overwrites(self):
        budget.set_budget(self.conn, self.user.id, "Food", "2026-09", 100)
        budget.set_budget(self.conn, self.user.id, "Food", "2026-09", 200)
        statuses = budget.budget_status(self.conn, self.user.id, "2026-09")
        self.assertEqual(len(statuses), 1)
        self.assertEqual(statuses[0].limit, 200.0)

    def test_summary_breakdown_trend(self):
        self.add("income", 1000, "Salary", "2026-09-01")
        self.add("expense", 300, "Food", "2026-09-02")
        self.add("expense", 100, "Transport", "2026-09-03")
        self.add("expense", 50, "Food", "2026-08-03")
        s = reports.monthly_summary(self.conn, self.user.id, "2026-09")
        self.assertEqual((s["income"], s["expense"], s["savings"]), (1000.0, 400.0, 600.0))
        breakdown = reports.category_breakdown(self.conn, self.user.id, "2026-09")
        self.assertEqual(breakdown[0], ("Food", 300.0, 75.0))
        trend = reports.monthly_trend(self.conn, self.user.id)
        self.assertEqual([m for m, _, _ in trend], ["2026-08", "2026-09"])

    def test_export_csv(self):
        self.add("expense", 10, "Food", "2026-09-01")
        with tempfile.TemporaryDirectory() as d:
            path = os.path.join(d, "out.csv")
            self.assertEqual(reports.export_csv(self.conn, self.user.id, path), 1)
            with open(path) as f:
                self.assertEqual(len(list(csv.reader(f))), 2)  # header + 1 row
