import unittest

from src.database import get_connection, init_db
from src import auth


class DBTestCase(unittest.TestCase):
    """Gives every test a fresh in-memory database and a registered user."""

    def setUp(self):
        self.conn = get_connection(":memory:")
        init_db(self.conn)
        self.user = auth.register(self.conn, "tester", "secret123")

    def tearDown(self):
        self.conn.close()
