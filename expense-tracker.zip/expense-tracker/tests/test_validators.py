import unittest

from src import validators as v


class ValidatorTests(unittest.TestCase):
    def test_amount_valid(self):
        self.assertEqual(v.validate_amount("12.345"), 12.35 if False else round(12.345, 2))

    def test_amount_invalid(self):
        for bad in ("abc", "-5", "0", None, "1e12"):
            with self.assertRaises(v.ValidationError):
                v.validate_amount(bad)

    def test_date(self):
        self.assertEqual(v.validate_date("2026-09-05"), "2026-09-05")
        with self.assertRaises(v.ValidationError):
            v.validate_date("05-09-2026")
        with self.assertRaises(v.ValidationError):
            v.validate_date("2026-02-30")

    def test_month(self):
        self.assertEqual(v.validate_month("2026-09"), "2026-09")
        with self.assertRaises(v.ValidationError):
            v.validate_month("2026-13")

    def test_type_and_username(self):
        self.assertEqual(v.validate_type(" Expense "), "expense")
        with self.assertRaises(v.ValidationError):
            v.validate_type("gift")
        with self.assertRaises(v.ValidationError):
            v.validate_username("a b")


if __name__ == "__main__":
    unittest.main()
