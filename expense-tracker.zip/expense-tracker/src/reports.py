"""Summaries, category breakdown, monthly trend and CSV export."""
import csv

from .validators import ValidationError, validate_month


def monthly_summary(conn, user_id, month):
    month = validate_month(month)
    rows = conn.execute(
        "SELECT type, COALESCE(SUM(amount),0) AS total FROM transactions"
        " WHERE user_id=? AND substr(date,1,7)=? GROUP BY type",
        (user_id, month),
    ).fetchall()
    totals = {r["type"]: round(r["total"], 2) for r in rows}
    income, expense = totals.get("income", 0.0), totals.get("expense", 0.0)
    return {"month": month, "income": income, "expense": expense,
            "savings": round(income - expense, 2)}


def category_breakdown(conn, user_id, month):
    """Expense per category for a month, as (category, total, percent) tuples."""
    month = validate_month(month)
    rows = conn.execute(
        "SELECT c.name, SUM(t.amount) AS total FROM transactions t"
        " JOIN categories c ON c.id=t.category_id"
        " WHERE t.user_id=? AND t.type='expense' AND substr(t.date,1,7)=?"
        " GROUP BY c.name ORDER BY total DESC",
        (user_id, month),
    ).fetchall()
    grand = sum(r["total"] for r in rows)
    return [(r["name"], round(r["total"], 2),
             round(r["total"] / grand * 100, 1) if grand else 0.0) for r in rows]


def monthly_trend(conn, user_id, months=6):
    """Income/expense per month for the most recent `months` months with data."""
    rows = conn.execute(
        "SELECT substr(date,1,7) AS m,"
        " SUM(CASE WHEN type='income' THEN amount ELSE 0 END) AS inc,"
        " SUM(CASE WHEN type='expense' THEN amount ELSE 0 END) AS exp"
        " FROM transactions WHERE user_id=? GROUP BY m ORDER BY m DESC LIMIT ?",
        (user_id, months),
    ).fetchall()
    return [(r["m"], round(r["inc"], 2), round(r["exp"], 2)) for r in reversed(rows)]


def text_bar(value, maximum, width=30):
    """Render a horizontal bar using # characters."""
    if maximum <= 0:
        return ""
    return "#" * max(1, round(value / maximum * width)) if value > 0 else ""


def export_csv(conn, user_id, path):
    rows = conn.execute(
        "SELECT t.id, t.date, t.type, c.name AS category, t.amount, t.description"
        " FROM transactions t JOIN categories c ON c.id=t.category_id"
        " WHERE t.user_id=? ORDER BY t.date, t.id",
        (user_id,),
    ).fetchall()
    try:
        with open(path, "w", newline="", encoding="utf-8") as f:
            writer = csv.writer(f)
            writer.writerow(["id", "date", "type", "category", "amount", "description"])
            for r in rows:
                writer.writerow(list(r))
    except OSError as exc:
        raise ValidationError(f"Could not write file: {exc}")
    return len(rows)
