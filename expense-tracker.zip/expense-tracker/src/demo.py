"""Non-interactive demo: seeds sample data and prints reports (useful for evaluators)."""
from . import auth, budget, reports, transactions
from .cli import print_transactions, show_budget_status, show_report
from .validators import ValidationError

SAMPLE = [
    ("income", 50000, "Salary", "2026-09-01", "September salary"),
    ("expense", 12000, "Rent", "2026-09-02", "Monthly rent"),
    ("expense", 3200, "Food", "2026-09-05", "Groceries"),
    ("expense", 900, "Transport", "2026-09-07", "Metro card recharge"),
    ("expense", 1800, "Entertainment", "2026-09-12", "Concert tickets"),
    ("expense", 2500, "Food", "2026-09-18", "Restaurants"),
    ("expense", 1500, "Utilities", "2026-09-20", "Electricity bill"),
    ("income", 48000, "Salary", "2026-08-01", "August salary"),
    ("expense", 12000, "Rent", "2026-08-02", "Monthly rent"),
    ("expense", 4100, "Food", "2026-08-10", "Groceries"),
]


def run_demo(conn):
    try:
        user = auth.register(conn, "demo", "demo1234")
        for t in SAMPLE:
            transactions.add_transaction(conn, user.id, *t[:4], description=t[4])
        budget.set_budget(conn, user.id, "Food", "2026-09", 5000)
        budget.set_budget(conn, user.id, "Entertainment", "2026-09", 1500)
        print("Created demo user 'demo' (password: demo1234) with sample data.")
    except ValidationError:
        user = auth.login(conn, "demo", "demo1234")
        print("Demo user already exists; using existing data.")
    print("\nAll transactions:")
    print_transactions(transactions.search_transactions(conn, user.id))
    print("\nBudget status for 2026-09:")
    show_budget_status(conn, user, "2026-09")
    show_report(conn, user, "2026-09")
    count = reports.export_csv(conn, user.id, "demo_export.csv")
    print(f"\nExported {count} rows to demo_export.csv")
