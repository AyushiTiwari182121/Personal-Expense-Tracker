"""Interactive command-line menu."""
from datetime import date
from getpass import getpass

from . import auth, budget, reports, transactions
from .logger import get_logger
from .validators import ValidationError

log = get_logger()


def ask(prompt, default=None):
    text = input(f"{prompt}" + (f" [{default}]" if default else "") + ": ").strip()
    return text or default


def print_transactions(items):
    if not items:
        print("No transactions found.")
        return
    print(f"{'ID':<5}{'Date':<12}{'Type':<9}{'Category':<15}{'Amount':>10}  Description")
    print("-" * 68)
    for t in items:
        print(f"{t.id:<5}{t.date:<12}{t.type:<9}{t.category:<15}{t.amount:>10.2f}  {t.description}")


def handle_add(conn, user):
    tx_type = ask("Type (income/expense)")
    amount = ask("Amount")
    category = ask("Category")
    tx_date = ask("Date YYYY-MM-DD", date.today().isoformat())
    desc = ask("Description (optional)", "")
    tx = transactions.add_transaction(conn, user.id, tx_type, amount, category, tx_date, desc)
    print(f"Saved transaction #{tx.id}.")
    if tx.type == "expense":
        alert = budget.check_alert(conn, user.id, tx.category, tx.date)
        if alert:
            print(alert)


def handle_view(conn, user):
    print_transactions(transactions.search_transactions(conn, user.id))


def handle_search(conn, user):
    print("Leave a filter blank to skip it.")
    items = transactions.search_transactions(
        conn, user.id,
        category=ask("Category", None), tx_type=ask("Type (income/expense)", None),
        date_from=ask("From date", None), date_to=ask("To date", None),
        min_amount=ask("Min amount", None), max_amount=ask("Max amount", None),
        keyword=ask("Keyword in description", None),
    )
    print_transactions(items)


def handle_edit(conn, user):
    tx_id = int(ask("Transaction ID"))
    current = transactions.get_transaction(conn, user.id, tx_id)
    print_transactions([current])
    changes = {}
    for field in ("type", "amount", "category", "date", "description"):
        value = ask(f"New {field} (blank to keep)", None)
        if value:
            changes[field] = value
    transactions.update_transaction(conn, user.id, tx_id, **changes)
    print("Updated.")


def handle_delete(conn, user):
    tx_id = int(ask("Transaction ID"))
    if ask("Type YES to confirm deletion", "no") == "YES":
        transactions.delete_transaction(conn, user.id, tx_id)
        print("Deleted.")
    else:
        print("Cancelled.")


def handle_set_budget(conn, user):
    budget.set_budget(conn, user.id, ask("Category"),
                      ask("Month YYYY-MM", date.today().strftime("%Y-%m")), ask("Limit"))
    print("Budget saved.")


def show_budget_status(conn, user, month):
    statuses = budget.budget_status(conn, user.id, month)
    if not statuses:
        print("No budgets set for that month.")
    for s in statuses:
        print(f"{s.category:<15} limit {s.limit:>9.2f}  spent {s.spent:>9.2f}  "
              f"left {s.remaining:>9.2f}  {s.percent_used:>5}%  [{s.state}]")


def handle_budget_status(conn, user):
    show_budget_status(conn, user, ask("Month YYYY-MM", date.today().strftime("%Y-%m")))


def show_report(conn, user, month):
    s = reports.monthly_summary(conn, user.id, month)
    print(f"\n=== Summary for {s['month']} ===")
    print(f"Income : {s['income']:>10.2f}\nExpense: {s['expense']:>10.2f}\nSavings: {s['savings']:>10.2f}")
    breakdown = reports.category_breakdown(conn, user.id, month)
    if breakdown:
        print("\nExpenses by category:")
        top = breakdown[0][1]
        for name, total, pct in breakdown:
            print(f"  {name:<15}{total:>9.2f} {pct:>5}%  {reports.text_bar(total, top)}")
    trend = reports.monthly_trend(conn, user.id)
    if trend:
        print("\nMonthly trend (expenses):")
        top = max(e for _, _, e in trend) or 1
        for m, inc, exp in trend:
            print(f"  {m}  in {inc:>9.2f}  out {exp:>9.2f}  {reports.text_bar(exp, top)}")


def handle_report(conn, user):
    show_report(conn, user, ask("Month YYYY-MM", date.today().strftime("%Y-%m")))


def handle_export(conn, user):
    path = ask("Output file", "transactions.csv")
    count = reports.export_csv(conn, user.id, path)
    print(f"Exported {count} transactions to {path}.")


MENU = [
    ("Add transaction", handle_add),
    ("View all transactions", handle_view),
    ("Search / filter transactions", handle_search),
    ("Edit transaction", handle_edit),
    ("Delete transaction", handle_delete),
    ("Set monthly budget", handle_set_budget),
    ("Budget status", handle_budget_status),
    ("Monthly report & trend", handle_report),
    ("Export to CSV", handle_export),
]


def user_menu(conn, user):
    while True:
        print(f"\n--- Expense Tracker | {user.username} ---")
        for i, (label, _) in enumerate(MENU, 1):
            print(f"{i}. {label}")
        print("0. Logout")
        choice = input("Choose: ").strip()
        if choice == "0":
            return
        if not choice.isdigit() or not 1 <= int(choice) <= len(MENU):
            print("Please enter a number from the menu.")
            continue
        try:
            MENU[int(choice) - 1][1](conn, user)
        except ValidationError as exc:
            print(f"Error: {exc}")
        except ValueError:
            print("Error: please enter a valid number.")
        except Exception as exc:  # last-resort guard so the app never crashes
            log.exception("Unexpected error")
            print(f"Unexpected error: {exc}")


def run(conn):
    print("Welcome to Personal Expense Tracker")
    while True:
        print("\n1. Login\n2. Register\n0. Exit")
        choice = input("Choose: ").strip()
        try:
            if choice == "1":
                user = auth.login(conn, ask("Username"), getpass("Password: "))
                user_menu(conn, user)
            elif choice == "2":
                user = auth.register(conn, ask("Username"), getpass("Password (min 6 chars): "))
                print("Account created. You are now logged in.")
                user_menu(conn, user)
            elif choice == "0":
                print("Goodbye!")
                return
            else:
                print("Invalid choice.")
        except ValidationError as exc:
            print(f"Error: {exc}")
        except (KeyboardInterrupt, EOFError):
            print("\nGoodbye!")
            return
