"""Monthly category budgets and overspend alerts."""
from .database import get_or_create_category
from .logger import get_logger
from .models import BudgetStatus
from .validators import validate_amount, validate_category, validate_month

log = get_logger()


def set_budget(conn, user_id, category, month, limit):
    category = validate_category(category)
    month = validate_month(month)
    limit = validate_amount(limit)
    cat_id = get_or_create_category(conn, category)
    conn.execute(
        "INSERT INTO budgets(user_id, category_id, month, limit_amount) VALUES (?,?,?,?)"
        " ON CONFLICT(user_id, category_id, month) DO UPDATE SET limit_amount=excluded.limit_amount",
        (user_id, cat_id, month, limit),
    )
    conn.commit()
    log.info("Budget set user=%s %s %s %.2f", user_id, category, month, limit)


def _spent(conn, user_id, category_id, month):
    row = conn.execute(
        "SELECT COALESCE(SUM(amount), 0) AS s FROM transactions"
        " WHERE user_id=? AND category_id=? AND type='expense' AND substr(date,1,7)=?",
        (user_id, category_id, month),
    ).fetchone()
    return round(row["s"], 2)


def budget_status(conn, user_id, month):
    """Return a BudgetStatus for every budget the user set for the month."""
    month = validate_month(month)
    rows = conn.execute(
        "SELECT b.category_id, c.name, b.limit_amount FROM budgets b"
        " JOIN categories c ON c.id = b.category_id"
        " WHERE b.user_id=? AND b.month=? ORDER BY c.name",
        (user_id, month),
    ).fetchall()
    return [BudgetStatus(r["name"], month, r["limit_amount"],
                         _spent(conn, user_id, r["category_id"], month)) for r in rows]


def check_alert(conn, user_id, category, date):
    """Return a warning string if the category budget is at/over 80%, else None."""
    month = date[:7]
    for status in budget_status(conn, user_id, month):
        if status.category == validate_category(category) and status.state != "OK":
            if status.state == "EXCEEDED":
                return (f"ALERT: {status.category} budget exceeded by "
                        f"{abs(status.remaining):.2f} for {month}.")
            return (f"Warning: {status.percent_used}% of your {status.category} "
                    f"budget used for {month}.")
    return None
