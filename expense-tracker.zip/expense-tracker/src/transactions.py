"""Transaction CRUD and search."""
from .database import get_or_create_category
from .logger import get_logger
from .models import Transaction
from .validators import (
    ValidationError, validate_amount, validate_category, validate_date, validate_type,
)

log = get_logger()

_BASE_QUERY = """
    SELECT t.id, t.user_id, t.type, t.amount, c.name AS category,
           t.description, t.date
    FROM transactions t JOIN categories c ON c.id = t.category_id
"""


def _row_to_tx(row):
    return Transaction(row["id"], row["user_id"], row["type"], row["amount"],
                       row["category"], row["description"], row["date"])


def add_transaction(conn, user_id, tx_type, amount, category, date, description=""):
    tx_type = validate_type(tx_type)
    amount = validate_amount(amount)
    category = validate_category(category)
    date = validate_date(date)
    cat_id = get_or_create_category(conn, category)
    cur = conn.execute(
        "INSERT INTO transactions(user_id, type, amount, category_id, description, date)"
        " VALUES (?, ?, ?, ?, ?, ?)",
        (user_id, tx_type, amount, cat_id, (description or "").strip()[:200], date),
    )
    conn.commit()
    log.info("Transaction added id=%s user=%s %s %.2f", cur.lastrowid, user_id, tx_type, amount)
    return get_transaction(conn, user_id, cur.lastrowid)


def get_transaction(conn, user_id, tx_id):
    row = conn.execute(_BASE_QUERY + " WHERE t.id = ? AND t.user_id = ?",
                       (tx_id, user_id)).fetchone()
    if not row:
        raise ValidationError(f"Transaction {tx_id} not found.")
    return _row_to_tx(row)


def update_transaction(conn, user_id, tx_id, **changes):
    """Update any of: type, amount, category, date, description."""
    current = get_transaction(conn, user_id, tx_id)
    tx_type = validate_type(changes.get("type", current.type))
    amount = validate_amount(changes.get("amount", current.amount))
    category = validate_category(changes.get("category", current.category))
    date = validate_date(changes.get("date", current.date))
    description = changes.get("description", current.description)
    cat_id = get_or_create_category(conn, category)
    conn.execute(
        "UPDATE transactions SET type=?, amount=?, category_id=?, date=?, description=?"
        " WHERE id=? AND user_id=?",
        (tx_type, amount, cat_id, date, description, tx_id, user_id),
    )
    conn.commit()
    log.info("Transaction updated id=%s user=%s", tx_id, user_id)
    return get_transaction(conn, user_id, tx_id)


def delete_transaction(conn, user_id, tx_id):
    get_transaction(conn, user_id, tx_id)  # raises if missing / not owned
    conn.execute("DELETE FROM transactions WHERE id=? AND user_id=?", (tx_id, user_id))
    conn.commit()
    log.info("Transaction deleted id=%s user=%s", tx_id, user_id)


def search_transactions(conn, user_id, category=None, tx_type=None, date_from=None,
                        date_to=None, min_amount=None, max_amount=None, keyword=None):
    """Return transactions for a user matching all supplied filters, newest first."""
    sql = _BASE_QUERY + " WHERE t.user_id = ?"
    params = [user_id]
    if category:
        sql += " AND c.name = ?"
        params.append(validate_category(category))
    if tx_type:
        sql += " AND t.type = ?"
        params.append(validate_type(tx_type))
    if date_from:
        sql += " AND t.date >= ?"
        params.append(validate_date(date_from))
    if date_to:
        sql += " AND t.date <= ?"
        params.append(validate_date(date_to))
    if min_amount is not None:
        sql += " AND t.amount >= ?"
        params.append(validate_amount(min_amount))
    if max_amount is not None:
        sql += " AND t.amount <= ?"
        params.append(validate_amount(max_amount))
    if keyword:
        sql += " AND t.description LIKE ?"
        params.append(f"%{keyword.strip()}%")
    sql += " ORDER BY t.date DESC, t.id DESC"
    return [_row_to_tx(r) for r in conn.execute(sql, params).fetchall()]
