"""Plain data classes used across the application."""
from dataclasses import dataclass


@dataclass
class User:
    id: int
    username: str


@dataclass
class Transaction:
    id: int
    user_id: int
    type: str
    amount: float
    category: str
    description: str
    date: str


@dataclass
class BudgetStatus:
    category: str
    month: str
    limit: float
    spent: float

    @property
    def remaining(self):
        return round(self.limit - self.spent, 2)

    @property
    def percent_used(self):
        return round(self.spent / self.limit * 100, 1) if self.limit else 0.0

    @property
    def state(self):
        if self.spent > self.limit:
            return "EXCEEDED"
        if self.percent_used >= 80:
            return "WARNING"
        return "OK"
