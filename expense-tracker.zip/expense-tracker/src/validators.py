"""Input validation helpers. Every user input passes through here."""
import re
from datetime import datetime


class ValidationError(ValueError):
    """Raised when user input is invalid."""


def validate_username(username):
    username = (username or "").strip()
    if not re.fullmatch(r"[A-Za-z0-9_]{3,20}", username):
        raise ValidationError(
            "Username must be 3-20 characters: letters, digits or underscore."
        )
    return username


def validate_password(password):
    if password is None or len(password) < 6:
        raise ValidationError("Password must be at least 6 characters long.")
    return password


def validate_amount(value):
    try:
        amount = round(float(value), 2)
    except (TypeError, ValueError):
        raise ValidationError("Amount must be a number.")
    if amount <= 0:
        raise ValidationError("Amount must be greater than zero.")
    if amount > 10_000_000:
        raise ValidationError("Amount is unrealistically large.")
    return amount


def validate_date(value):
    try:
        return datetime.strptime(value.strip(), "%Y-%m-%d").strftime("%Y-%m-%d")
    except (AttributeError, ValueError):
        raise ValidationError("Date must be in YYYY-MM-DD format.")


def validate_month(value):
    try:
        return datetime.strptime(value.strip(), "%Y-%m").strftime("%Y-%m")
    except (AttributeError, ValueError):
        raise ValidationError("Month must be in YYYY-MM format.")


def validate_type(value):
    value = (value or "").strip().lower()
    if value not in ("income", "expense"):
        raise ValidationError("Type must be 'income' or 'expense'.")
    return value


def validate_category(name):
    name = (name or "").strip().title()
    if not re.fullmatch(r"[A-Za-z ]{2,30}", name):
        raise ValidationError("Category must be 2-30 letters/spaces.")
    return name
