"""SQLite connection and schema management."""
import sqlite3

DEFAULT_CATEGORIES = [
    "Food", "Transport", "Rent", "Utilities", "Entertainment",
    "Health", "Shopping", "Education", "Salary", "Other",
]

SCHEMA = """
CREATE TABLE IF NOT EXISTS users (
    id            INTEGER PRIMARY KEY AUTOINCREMENT,
    username      TEXT NOT NULL UNIQUE,
    password_hash TEXT NOT NULL,
    salt          TEXT NOT NULL,
    created_at    TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS categories (
    id   INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL UNIQUE
);
CREATE TABLE IF NOT EXISTS transactions (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id     INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    type        TEXT NOT NULL CHECK (type IN ('income', 'expense')),
    amount      REAL NOT NULL CHECK (amount > 0),
    category_id INTEGER NOT NULL REFERENCES categories(id),
    description TEXT DEFAULT '',
    date        TEXT NOT NULL,
    created_at  TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS budgets (
    id           INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id      INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    category_id  INTEGER NOT NULL REFERENCES categories(id),
    month        TEXT NOT NULL,
    limit_amount REAL NOT NULL CHECK (limit_amount > 0),
    UNIQUE (user_id, category_id, month)
);
CREATE INDEX IF NOT EXISTS idx_tx_user_date ON transactions(user_id, date);
"""


def get_connection(db_path="expenses.db"):
    """Open a connection with foreign keys on and rows accessible by name."""
    conn = sqlite3.connect(db_path)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON")
    return conn


def init_db(conn):
    """Create tables and seed default categories."""
    conn.executescript(SCHEMA)
    conn.executemany(
        "INSERT OR IGNORE INTO categories(name) VALUES (?)",
        [(c,) for c in DEFAULT_CATEGORIES],
    )
    conn.commit()


def get_or_create_category(conn, name):
    """Return the id of a category, creating it if it does not exist."""
    row = conn.execute("SELECT id FROM categories WHERE name = ?", (name,)).fetchone()
    if row:
        return row["id"]
    cur = conn.execute("INSERT INTO categories(name) VALUES (?)", (name,))
    conn.commit()
    return cur.lastrowid
