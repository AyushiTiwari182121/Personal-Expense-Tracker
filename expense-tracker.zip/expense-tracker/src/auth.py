"""User registration and login using salted PBKDF2 password hashing."""
import hashlib
import hmac
import os
import sqlite3

from .logger import get_logger
from .models import User
from .validators import ValidationError, validate_password, validate_username

log = get_logger()
ITERATIONS = 200_000


def hash_password(password, salt=None):
    """Return (hash_hex, salt_hex). A new random salt is made if none is given."""
    salt_bytes = bytes.fromhex(salt) if salt else os.urandom(16)
    digest = hashlib.pbkdf2_hmac("sha256", password.encode(), salt_bytes, ITERATIONS)
    return digest.hex(), salt_bytes.hex()


def register(conn, username, password):
    username = validate_username(username)
    validate_password(password)
    pw_hash, salt = hash_password(password)
    try:
        cur = conn.execute(
            "INSERT INTO users(username, password_hash, salt) VALUES (?, ?, ?)",
            (username, pw_hash, salt),
        )
        conn.commit()
    except sqlite3.IntegrityError:
        raise ValidationError("That username is already taken.")
    log.info("User registered: %s", username)
    return User(id=cur.lastrowid, username=username)


def login(conn, username, password):
    row = conn.execute(
        "SELECT id, username, password_hash, salt FROM users WHERE username = ?",
        ((username or "").strip(),),
    ).fetchone()
    if row:
        candidate, _ = hash_password(password or "", row["salt"])
        if hmac.compare_digest(candidate, row["password_hash"]):
            log.info("Login success: %s", username)
            return User(id=row["id"], username=row["username"])
    log.warning("Login failed for username: %s", username)
    raise ValidationError("Invalid username or password.")
