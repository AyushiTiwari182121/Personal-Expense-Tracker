"""Entry point.  Usage:  python main.py [--demo] [--db PATH]"""
import argparse
import sys

from src.database import get_connection, init_db
from src.logger import get_logger


def main():
    parser = argparse.ArgumentParser(description="Personal Expense Tracker (CLI)")
    parser.add_argument("--db", default="expenses.db", help="SQLite database file")
    parser.add_argument("--demo", action="store_true",
                        help="seed sample data and print reports without prompts")
    args = parser.parse_args()
    log = get_logger()

    try:
        conn = get_connection(args.db)
        init_db(conn)
    except Exception as exc:
        log.exception("Database initialisation failed")
        print(f"Could not open database: {exc}")
        sys.exit(1)

    try:
        if args.demo:
            from src.demo import run_demo
            run_demo(conn)
        else:
            from src.cli import run
            run(conn)
    finally:
        conn.close()


if __name__ == "__main__":
    main()
