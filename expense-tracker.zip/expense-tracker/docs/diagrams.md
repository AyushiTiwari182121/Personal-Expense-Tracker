# Design Diagrams (Mermaid)

GitHub renders these automatically. To get images for the PDF report, paste each block
into https://mermaid.live and export as PNG.

## 1. System Architecture
```mermaid
flowchart TB
    U[User - Terminal] --> CLI[cli.py - menus and prompts]
    CLI --> AUTH[auth.py]
    CLI --> TX[transactions.py]
    CLI --> BUD[budget.py]
    CLI --> REP[reports.py]
    AUTH --> VAL[validators.py]
    TX --> VAL
    BUD --> VAL
    REP --> VAL
    AUTH --> DB[(database.py - SQLite)]
    TX --> DB
    BUD --> DB
    REP --> DB
    AUTH -.-> LOG[logger.py - app.log]
    TX -.-> LOG
    BUD -.-> LOG
```

## 2. Use Case Diagram
```mermaid
flowchart LR
    User((User))
    User --- UC1[Register]
    User --- UC2[Login]
    User --- UC3[Add transaction]
    User --- UC4[Edit / delete transaction]
    User --- UC5[Search transactions]
    User --- UC6[Set budget]
    User --- UC7[View budget status]
    User --- UC8[View reports and trend]
    User --- UC9[Export CSV]
    UC3 -. includes .-> UC10[Validate input]
    UC3 -. extends .-> UC11[Show budget alert]
```

## 3. Workflow Diagram
```mermaid
flowchart TD
    A([Start]) --> B{Login or Register}
    B -->|Invalid| B
    B -->|Success| C[User menu]
    C --> D[Add / edit / delete / search]
    C --> E[Set budget or view status]
    C --> F[View reports]
    C --> G[Export CSV]
    D --> H{Input valid?}
    H -->|No| I[Show error] --> C
    H -->|Yes| J[Save to database] --> K{Budget near or over limit?}
    K -->|Yes| L[Show alert] --> C
    K -->|No| C
    E --> C
    F --> C
    G --> C
    C -->|Logout| A2([End])
```

## 4. Sequence Diagram - Add an Expense
```mermaid
sequenceDiagram
    actor User
    participant CLI as cli.py
    participant VAL as validators.py
    participant TX as transactions.py
    participant DB as SQLite
    participant BUD as budget.py
    User->>CLI: choose "Add transaction"
    CLI->>User: prompt type, amount, category, date
    User->>CLI: enter values
    CLI->>TX: add_transaction(...)
    TX->>VAL: validate all fields
    VAL-->>TX: cleaned values or ValidationError
    TX->>DB: INSERT transaction
    DB-->>TX: new id
    TX-->>CLI: Transaction
    CLI->>BUD: check_alert(category, date)
    BUD->>DB: sum expenses, read budget
    BUD-->>CLI: alert text or None
    CLI-->>User: confirmation and alert
```

## 5. Class Diagram
```mermaid
classDiagram
    class User { +int id +str username }
    class Transaction { +int id +int user_id +str type +float amount +str category +str description +str date }
    class BudgetStatus { +str category +str month +float limit +float spent +remaining() +percent_used() +state() }
    class AuthService { +register() +login() +hash_password() }
    class TransactionService { +add_transaction() +update_transaction() +delete_transaction() +search_transactions() }
    class BudgetService { +set_budget() +budget_status() +check_alert() }
    class ReportService { +monthly_summary() +category_breakdown() +monthly_trend() +export_csv() }
    AuthService --> User
    TransactionService --> Transaction
    BudgetService --> BudgetStatus
    User "1" --> "*" Transaction
```
(In the code the services are module-level functions in `auth.py`, `transactions.py`,
`budget.py` and `reports.py`; they are drawn as classes to show responsibilities.)

## 6. ER Diagram
```mermaid
erDiagram
    USERS ||--o{ TRANSACTIONS : records
    USERS ||--o{ BUDGETS : sets
    CATEGORIES ||--o{ TRANSACTIONS : classifies
    CATEGORIES ||--o{ BUDGETS : limits
    USERS { int id PK string username UK string password_hash string salt datetime created_at }
    CATEGORIES { int id PK string name UK }
    TRANSACTIONS { int id PK int user_id FK int category_id FK string type float amount string description string date datetime created_at }
    BUDGETS { int id PK int user_id FK int category_id FK string month float limit_amount }
```
