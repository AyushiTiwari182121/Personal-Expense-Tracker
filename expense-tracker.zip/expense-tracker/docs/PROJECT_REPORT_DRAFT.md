# Project Report - Personal Expense Tracker
> DRAFT OUTLINE. Rewrite each section in your own words, add your real screenshots and
> diagram images, then export to PDF (Word/Google Docs -> Save as PDF) for the portal.

## 1. Cover Page
Project title: Personal Expense Tracker (CLI)
Student name: ____________   Registration No.: ____________
Course name & code: ____________   Faculty: ____________
Submission date: ____________   GitHub: https://github.com/<username>/<repo>

## 2. Introduction
Why personal finance tracking matters, why a CLI/offline tool was chosen, and a
2-3 sentence summary of what the application does.

## 3. Problem Statement
(Summarise statement.md: people lose track of spending; existing tools are heavy or online.)

## 4. Functional Requirements
- FR1 Register and log in securely
- FR2 Add, view, edit, delete transactions
- FR3 Search/filter by category, type, dates, amount, keyword
- FR4 Set monthly budgets per category
- FR5 Alert when a budget is >= 80% used or exceeded
- FR6 Monthly summary, category breakdown and multi-month trend
- FR7 Export data to CSV

## 5. Non-Functional Requirements
- Security: PBKDF2-SHA256 with per-user salt; parameterised SQL; per-user data isolation
- Reliability / error handling: all input validated; app never crashes on bad input
- Usability: numbered menus, defaults for dates, clear error messages
- Maintainability: layered modules, docstrings, unit tests
- Logging: events and errors written to logs/app.log
- Performance: indexed queries; responses are instant for thousands of records

## 6. System Architecture
Insert Architecture diagram (docs/diagrams.md #1). Explain the layers:
presentation (cli.py) -> service modules -> validators -> database.

## 7. Design Diagrams
Use case, workflow, sequence, class and ER diagrams (docs/diagrams.md #2-#6),
each with a short caption explaining what it shows.

## 8. Design Decisions & Rationale
- Why SQLite (zero setup, file based, SQL features, ships with Python)
- Why standard library only (easy evaluation, no dependency issues)
- Why layered modules (separation of concerns, testability)
- Why PBKDF2 (built in, slow by design, salted)
- Why amounts are validated to 2 decimals, dates stored as ISO text (sortable)

## 9. Implementation Details
Describe each module in a short paragraph (auth, transactions, budget, reports,
validators, database, cli, logger, demo) and any interesting logic
(e.g. the upsert used for budgets, SQL aggregation for reports).

## 10. Screenshots / Results
Paste screenshots from YOUR runs: registration, adding a transaction, alert message,
monthly report with bar charts, test results, log file.

## 11. Testing Approach
22 unittest cases using an in-memory SQLite database per test: validators, auth
(hashing, wrong password, duplicate user), CRUD, search filters, user data isolation,
budget states, alerts, reports, CSV export. Also manual testing with `--demo`.
Include the output of `python -m unittest discover -s tests -t . -v`.

## 12. Challenges Faced
Write your genuine experience, e.g. designing budget alert logic, handling invalid
input, storing dates for month-wise grouping, testing without touching the real database.

## 13. Learnings & Key Takeaways
What you learned about modular design, SQL aggregation, secure password storage,
testing and Git.

## 14. Future Enhancements
Recurring transactions, multi-currency support, charts with matplotlib, a web/GUI front
end, data import from bank statements, encrypted database.

## 15. References
Python docs (sqlite3, hashlib, unittest, logging), SQLite documentation, OWASP Password
Storage Cheat Sheet, Mermaid documentation. List only what you actually used.
